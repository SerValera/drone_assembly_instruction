Launch nodes: APM Ardupilot Mavros, Realsence d435, t254.

```sh
roslaunch racing_pkg apm_dataset_collection.launch
```

To enable mavros IMU stream 
```sh
rosrun mavros mavsys rate --all 100
```

Data set collection. 
Record Depth Point cloud, RGB, FishEye1, FishEye2, IMU drone, IMU acc odom T265, vicon pose. 

```sh
rosbag record /t265/camera/fisheye1/image_raw /t265/camera/fisheye2/image_raw /d435/camera/color/image_raw /d435/camera/depth/image_rect_raw /t265/camera/odom/sample /t265/camera/gyro/sample /t265/camera/accel/sample /tf /tf_static /vicon/red/red /mavros/imu/data_raw /d435/camera/depth/color/points
```

Some command to test
```sh
roslaunch realsense2_camera rs_camera.launch filters:=pointcloud
roslaunch realsense2_camera rs_camera.launch filters:=colorizer,pointcloud align_depth:=true pointcloud_texture_stream:=RS2_STREAM_COLOR
roslaunch realsense2_camera rs_camera.launch filters:=colorizer,pointcloud align_depth:=true pointcloud_texture_stream:=RS2_STREAM_COLOR ordered_pc:=true initial_reset:=true
```
