
"use strict";

let viconGrabPose = require('./viconGrabPose.js')
let viconCalibrateSegment = require('./viconCalibrateSegment.js')

module.exports = {
  viconGrabPose: viconGrabPose,
  viconCalibrateSegment: viconCalibrateSegment,
};
